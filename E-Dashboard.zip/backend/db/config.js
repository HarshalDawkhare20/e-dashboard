// all configuration files are kept in this file

// const mongoose=require("mongoose");
// mongoose.connect("mongodb://localhost:27017/e-commerce")

const mongoose = require("mongoose");
mongoose.connect("mongodb://localhost:27017/e-commerce");